# GRIDTECH submission format v5.5.1
Submit runnable product/code with instructions, short method README, readable results summary, portfolio.json and dispatch.csv. Add files to the Submission Folder in your Team Google Drive Folder by 5:00p.m., as specified in the released prompt. Show your recommendation and demonstrate how changing a customer priority affects it. A separate alternative-portfolio submission is not required. Put your recommended result as portfolio.json and dispatch.csv at the top level of your Submission Folder. Put any alternatives, priority-change results or extensions in clearly labeled subfolders. Upload CSVs as files; do not convert them to Google Sheets.

portfolio.json requires exactly these keys:
```json
{"initial_service_month":20,"grid_delay_months":0,"capacities_mw":{"utility_solar":0,"wind":0,"battery_4h":0,"gas_turbine":0,"gas_engine":0,"fuel_cell":0,"nuclear":0}}
```
This is a format example, NOT a feasible solution. Omit unused energy-resource IDs or set them to zero. No prescribed customer weights. initial_service_month and grid_delay_months are integer months; capacities are MW. Full-demand month is derived as initial_service_month+10. The required baseline uses grid_delay_months=0; alternative customer start dates are supported. Exploring arbitrary nonnegative grid delays is optional. Additional valuations belong in your product/README, not hidden changes to common inputs.

Dispatch CSV requires87,600 rows ordered by model_hour0..87599, including zero-demand preopening hours. Columns are listed in examples/dispatch_header.csv and data/data_dictionary.csv. Every power flow is hourly-averageMW, numerically equal toMWh for its one-hour interval. battery_4h_soc_mwh is internal stored energy at ENDofhour. grid_mw is residual merchant electricity, not all offsite imports. tier1_relocated_mw is local-equivalent demand moved, not remote electricity; multiply by 1.05 for remoteMWh. tier2_curtailed_mw is interrupted customer demand, not curtailed generation. Include zero columns for unused resources. Do not submit reference timestamps as the chronological primary key.

```
python starter/check_submission.py portfolio.json dispatch.csv > check_results.json
```
If the check fails, `check_results.json` is empty and the reason is printed in the terminal.
The checker recomputes demand, limits and costs from submitted metadata and unchanged shared inputs, so altered output load columns cannot hide a mismatch. On a passing submission it produces horizon totals, annual_results, capacity_cost_ledger and timing/physical diagnostics in JSON. These are **common benchmark calculations, not competition rankings**. Readable checker code reveals some model logic; no optimizer or report-generation tool is supplied; `prepare_inputs()` in the checker may be imported to build inputs (README section 2). Technical checks do not establish optimality or evaluate your UI. Judges assess customer workflow, reasoning and the demonstration; a technical reviewer can run these checks on exports. Extensions should be submitted separately alongside a checked common-model result.

For alternative initial-service dates, use the documented month-to-hour conversion and the relative ramp in `MODEL_RULES.md`, the reference profiles and unchanged grid/resource dates, or import `prepare_inputs()` from `starter/check_submission.py`. The default timeline is for month 20 only; do not substitute it for a different opening date. This packet does not prescribe a preference or dispatch method.
